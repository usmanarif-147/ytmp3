<div>
    <div>
        <div class="d-flex justify-content-between">
            <h2 class="card-header">
                <a href="<?php echo e(url('admin/pages')); ?>"> Pages </a> / <?php echo e($heading); ?>

            </h2>
        </div>
    </div>
    <div class="row">
        <div class="col-xl">
            <div class="card mb-4">
                <form wire:submit.prevent="store">
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-10">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label class="form-label">
                                                    Question : <?php echo e($index + 1); ?> <span class="text-danger"> * </span>
                                                    <?php $__errorArgs = ['questions.' . $index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger error-message"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </label>
                                                <textarea class="form-control" wire:model.defer="questions.<?php echo e($index); ?>" rows="3"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label class="form-label">
                                                    Answer <span class="text-danger"> * </span>
                                                    <?php $__errorArgs = ['answers.' . $index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger error-message"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </label>
                                                <textarea class="form-control" wire:model.defer="answers.<?php echo e($index); ?>" rows="3"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php if($index): ?>
                                    <div class="col-2">
                                        <div class="row">
                                            <div class="col-12">
                                                <button type="button" class="btn btn-danger"
                                                    wire:click="removeFaq(<?php echo e($index); ?>)">
                                                    Remove
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-footer">
                        <button type="button" class="btn btn-success" wire:click="addNewFaq">Add</button>
                        <?php if(count($questions)): ?>
                            <button type="submit" class="btn btn-primary">Save</button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('script'); ?>
    <script>
        window.addEventListener('swal:modal', event => {
            swal({
                title: event.detail.message,
                icon: event.detail.type,
            });
        });

        $(document).on('click', '.swal-button', function() {
            location.href = "<?php echo e(route('pages')); ?>";
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\personal_fiv\Fiver\ytmp\YTMP3\resources\views/livewire/admin/page-content/faq/add-faq.blade.php ENDPATH**/ ?>