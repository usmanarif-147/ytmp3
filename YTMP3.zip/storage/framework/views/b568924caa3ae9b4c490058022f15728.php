 <!-- / Layout wrapper -->

 <!-- Helpers -->
 <script src="<?php echo e(asset('assets/vendor/js/helpers.js')); ?>"></script>

 <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
 <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
 <script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>

 <!-- Core JS -->
 <!-- build:js assets/vendor/js/core.js -->
 <script src="<?php echo e(asset('assets/vendor/libs/jquery/jquery.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/vendor/libs/popper/popper.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/vendor/js/bootstrap.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>

 <script src="<?php echo e(asset('assets/vendor/js/menu.js')); ?>"></script>
 <!-- endbuild -->

 <!-- Vendors JS -->
 

 <!-- Main JS -->
 <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

 <!-- Page JS -->
 <script src="<?php echo e(asset('assets/js/dashboards-analytics.js')); ?>"></script>
 <script src="<?php echo e(asset('assets/js/pages-account-settings-account.js')); ?>"></script>

 <!-- Place this tag in your head or just before your close body tag. -->
 <script async defer src="https://buttons.github.io/buttons.js"></script>

 

 <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

 
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.blockUI/2.70/jquery.blockUI.min.js"
     integrity="sha512-eYSzo+20ajZMRsjxB6L7eyqo5kuXuS2+wEbbOkpaur+sA2shQameiJiWEzCIDwJqaB0a4a6tCuEvCOBHUg3Skg=="
     crossorigin="anonymous" referrerpolicy="no-referrer"></script>

 
<?php /**PATH D:\personal_fiv\Fiver\ytmp\YTMP3\resources\views/partials/js.blade.php ENDPATH**/ ?>