<div>
    <div>
        <div class="d-flex justify-content-between">
            <h2 class="card-header">
                <?php echo e($heading); ?>

                <span>
                    <h5 style="margin-top:10px"> Total: <?php echo e($total); ?> </h4>
                </span>
            </h2>
            <h5 class="card-header">
                <a class="btn btn-primary" href="<?php echo e(route('create.language')); ?>"> Create
                </a>
            </h5>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-md-3 offset-md-6">
                    <label for=""> Select status </label>
                    <select wire:model="filterByStatus" class="form-control form-select me-2">
                        <option value="" selected> Select Status </option>
                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($val); ?>"><?php echo e($status); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for=""> Search by Name </label>
                    <input class="form-control me-2" type="search" wire:model.debounce.500ms="searchQuery"
                        placeholder="Search" aria-label="Search">
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="table-responsive text-nowrap">
                    <table class="table admin-table">
                        <thead class="table-light">
                            <tr>
                                <th> Image </th>
                                <th> Name </th>
                                <th> Lang </th>
                                <th> Content Uploaded </th>
                                <th> Status </th>
                                <th> Actions </th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php $__currentLoopData = $langs['langs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="img-holder">
                                            <img src="<?php echo e(asset(isImageExist($lang->flag))); ?>" alt="">
                                        </div>
                                    </td>
                                    <td> <?php echo e($lang->name); ?></td>
                                    <td> <?php echo e($lang->lang); ?></td>
                                    <td>
                                        <span
                                            class="badge <?php echo e($lang->content ? 'bg-label-success' : 'bg-label-danger'); ?> me-1">
                                            <?php echo e($lang->content ? 'Uploaded' : 'Not Uploaded'); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <span
                                            class="badge <?php echo e($lang->status ? 'bg-label-success' : 'bg-label-danger'); ?> me-1">
                                            <?php echo e($lang->status ? 'Activated' : 'Deactivated'); ?>

                                        </span>
                                    </td>
                                    <td class="action-td">
                                        <?php if(!$lang->status): ?>
                                            <button class="btn btn-icon btn-outline-secondary" data-bs-toggle="tooltip"
                                                data-bs-offset="0,4" data-bs-placement="top" data-bs-html="true"
                                                title="" data-bs-original-title="<span>Activate</span>"
                                                wire:click="activateConfirmModal(<?php echo e($lang->id); ?>)">
                                                <i class="fa fa-eye"></i>
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-icon btn-outline-secondary" data-bs-toggle="tooltip"
                                                data-bs-offset="0,4" data-bs-placement="top" data-bs-html="true"
                                                title="" data-bs-original-title="<span>Deactivate</span>"
                                                wire:click="deactivateConfirmModal(<?php echo e($lang->id); ?>)">
                                                <i class="fa fa-eye-slash"></i>
                                            </button>
                                        <?php endif; ?>
                                        <a class="btn btn-icon btn-outline-secondary" data-bs-toggle="tooltip"
                                            data-bs-offset="0,4" data-bs-placement="top" data-bs-html="true"
                                            title="" data-bs-original-title="<span>Edit</span>"
                                            href="<?php echo e(route('edit.language', $lang->id)); ?>">
                                            <i class="fa fa-pencil"></i>
                                        </a>
                                    </td>

                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="demo-inline-spacing">
                        <?php if($langs['langs']->count() > 0): ?>
                            <?php echo e($langs['langs']->links()); ?>

                        <?php else: ?>
                            <p class="text-center"> No Record Found </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- Modal -->
    <?php echo $__env->make('partials.confirm_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>

<?php $__env->startSection('script'); ?>
    <script>
        window.addEventListener('swal:modal', event => {
            $('#confirmModal').modal('hide');
            swal({
                title: event.detail.message,
                icon: event.detail.type,
            });
        });

        window.addEventListener('close-modal', event => {
            $('#confirmModal').modal('hide');
        });

        window.addEventListener('confirm-modal', event => {
            $('#confirmModal').modal('show');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\personal_fiv\Fiver\ytmp\YTMP3\resources\views/livewire/admin/language/languages.blade.php ENDPATH**/ ?>