<div>
    <div>
        <div class="d-flex justify-content-between">
            <h2 class="card-header">
                <a href="<?php echo e(url('admin/pages')); ?>"> Pages </a> / <?php echo e($heading); ?>

            </h2>
        </div>
    </div>

    <div class="row">
        <div class="col-xl">
            <div class="card mb-4">
                <form wire:submit.prevent="update">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6">
                                <?php $__errorArgs = ['item_prop_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger error-message"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="d-flex align-items-start align-items-sm-center gap-4">

                                    <?php if($item_prop_image && !is_string($item_prop_image)): ?>
                                        <img src="<?php echo e($item_prop_image->temporaryUrl()); ?>" alt="user-avatar"
                                            class="d-block rounded" height="200" width="170">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset(isImageExist($item_prop_image_preview))); ?>" alt="user-avatar"
                                            class="d-block rounded" height="200" width="170">
                                    <?php endif; ?>

                                    <div wire:loading wire:target="item_prop_image" wire:key="item_prop_image">
                                        <i class="fa fa-spinner fa-spin mt-2 ml-2"></i>
                                    </div>
                                    <div class="icon-upload btn btn-primary">
                                        <span>Upload Item Prop Image</span>
                                        <input type="file" class="icon-input" wire:model="item_prop_image"
                                            accept="image/png, image/jpeg, image/jpg, image/gif">
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <?php $__errorArgs = ['og_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger error-message"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="d-flex align-items-start align-items-sm-center gap-4">
                                    <?php if($og_image && !is_string($og_image)): ?>
                                        <img src="<?php echo e($og_image->temporaryUrl()); ?>" alt="user-avatar"
                                            class="d-block rounded" height="200" width="170">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset(isImageExist($og_image_preview))); ?>" alt="user-avatar"
                                            class="d-block rounded" height="200" width="170">
                                    <?php endif; ?>

                                    <div wire:loading wire:target="og_image" wire:key="og_image">
                                        <i class="fa fa-spinner fa-spin mt-2 ml-2"></i>
                                    </div>
                                    <div class="icon-upload btn btn-primary">
                                        <span>Upload Og Image</span>
                                        <input type="file" class="icon-input" wire:model="og_image"
                                            accept="image/png, image/jpeg, image/jpg, image/gif">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">
                                        Title <span class="text-danger"> * </span>
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger error-message"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="text" wire:model="title" class="form-control"
                                        placeholder="Enter Title">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">
                                        Robots <span class="text-danger"> * </span>
                                        <?php $__errorArgs = ['robots'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger error-message"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="text" wire:model="robots" class="form-control"
                                        placeholder="Enter Robots">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">
                                        Item Prop Name <span class="text-danger"> * </span>
                                        <?php $__errorArgs = ['item_prop_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger error-message"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="text" wire:model="item_prop_name" class="form-control"
                                        placeholder="Enter Item Prop Name">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">
                                        Canonical <span class="text-danger"> * </span>
                                        <?php $__errorArgs = ['canonical'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger error-message"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="text" wire:model="canonical" class="form-control"
                                        placeholder="Enter Canonical">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">
                                        Og type <span class="text-danger"> * </span>
                                        <?php $__errorArgs = ['og_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger error-message"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="text" wire:model="og_type" class="form-control"
                                        placeholder="Enter Og Type">
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">
                                        Og title <span class="text-danger"> * </span>
                                        <?php $__errorArgs = ['og_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger error-message"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="text" wire:model="og_title" class="form-control"
                                        placeholder="Enter Og Title">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>

<?php $__env->startSection('script'); ?>
    <script>
        window.addEventListener('swal:modal', event => {
            swal({
                title: event.detail.message,
                icon: event.detail.type,
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\personal_fiv\Fiver\ytmp\YTMP3\resources\views/livewire/admin/page-content/static-meta/edit-static-meta.blade.php ENDPATH**/ ?>