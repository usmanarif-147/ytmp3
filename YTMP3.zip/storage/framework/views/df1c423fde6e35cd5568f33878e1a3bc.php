<p>
    Terms of use
</p>
<?php /**PATH D:\personal_fiv\Fiver\ytmp\YTMP3\resources\views/terms-of-user.blade.php ENDPATH**/ ?>