<div wire:ignore.self class="modal fade" id="confirmModal" tabindex="-1" aria-labelledby="confirmModalLabel"
    aria-hidden="true">
    <form wire:submit.prevent="<?php echo e($methodType); ?>">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content text-center">
                <div class="modal-header">
                    <h3 class="modal-title w-100" id="disableLabel"><?php echo e($modalTitle); ?></h5>
                        <button type="button" class="btn-close" wire:click="closeModal" data-bs-dismiss="modal"
                            aria-label="Close">
                        </button>
                </div>
                <div class="modal-body">
                    <p style="font-size: 20px"><?php echo e($modalBody); ?></p>
                </div>
                <div class="modal-footer justify-content-center">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"
                        wire:click="closeModal">Close</button>
                    <button type="submit" class="btn <?php echo e($modalActionBtnColor); ?>" style="color:white">
                        <?php echo e($modalActionBtnText); ?>

                    </button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php /**PATH D:\personal_fiv\Fiver\ytmp\YTMP3\resources\views/partials/confirm_modal.blade.php ENDPATH**/ ?>