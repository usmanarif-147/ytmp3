<div>
    <div>
        <div class="d-flex justify-content-between">
            <h2 class="card-header">
                <a href="<?php echo e(url('admin/pages')); ?>"> Pages </a> / <?php echo e($heading); ?>

            </h2>
        </div>
    </div>
    <div class="row">
        <div class="col-xl">
            <div class="card mb-4">
                <form wire:submit.prevent="update">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-6">
                                <div class="mb-3">
                                    <div class="d-flex align-items-start align-items-sm-center gap-4">
                                        <?php if($feature_image && !is_string($feature_image)): ?>
                                            <img src="<?php echo e($feature_image->temporaryUrl()); ?>" alt="user-avatar"
                                                class="d-block rounded" height="200" width="170">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset(isImageExist($feature_image_preview))); ?>"
                                                alt="user-avatar" class="d-block rounded" height="200" width="170">
                                        <?php endif; ?>

                                        <div wire:loading wire:target="feature_image" wire:key="feature_image">
                                            <i class="fa fa-spinner fa-spin mt-2 ml-2"></i>
                                        </div>

                                        <div class="icon-upload btn btn-primary">
                                            <span>Upload Feature Image</span>
                                            <input type="file" class="icon-input" wire:model="feature_image"
                                                accept="image/png, image/jpeg, image/jpg, image/webp">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="mb-3">
                                    <label class="form-label">
                                        Feature Title <span class="text-danger"> * </span>
                                        <?php $__errorArgs = ['feature_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger error-message"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="text" wire:model="feature_title" class="form-control"
                                        placeholder="Enter Feature Title">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="mb-3">
                                    <label class="form-label">
                                        Feature Description <span class="text-danger"> * </span>
                                        <?php $__errorArgs = ['feature_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger error-message"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <div wire:ignore>
                                        <textarea class="form-control" id="ck_feature" wire:model.defer="feature_description">
                                            <?php echo e($feature_description); ?>

                                        </textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('script'); ?>
    <script>
        window.addEventListener('swal:modal', event => {
            swal({
                title: event.detail.message,
                icon: event.detail.type,
            });
        });

        let settings = {
            toolbar: ['heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList',
                'blockQuote'
            ],
            heading: {
                options: [{
                        model: 'paragraph',
                        title: 'Paragraph',
                        class: 'ck-heading_paragraph'
                    },
                    {
                        model: 'heading1',
                        view: 'h1',
                        title: 'Heading 1',
                        class: 'ck-heading_heading1'
                    },
                    {
                        model: 'heading2',
                        view: 'h2',
                        title: 'Heading 2',
                        class: 'ck-heading_heading2'
                    }
                ]
            }
        }

        document.addEventListener("DOMContentLoaded", function() {

            ClassicEditor
                .create(document.querySelector('#ck_feature'), settings)
                .then(useeditor => {
                    let ckeditor;
                    ckeditor = useeditor;
                    ckeditor.model.document.on('change:data', () => {
                        console.log(ckeditor.getData())
                        window.livewire.find('<?php echo e($_instance->id); ?>').set('feature_description', ckeditor.getData());
                    })
                })
                .catch(error => {
                    console.error(error);
                });

        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\personal_fiv\Fiver\ytmp\YTMP3\resources\views/livewire/admin/page-content/feature/edit-feature.blade.php ENDPATH**/ ?>