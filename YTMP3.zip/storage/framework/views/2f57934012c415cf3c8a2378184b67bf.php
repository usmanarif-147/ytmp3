<div>
    <div>
        <div class="d-flex justify-content-between">
            <h2 class="card-header">
                <a href="<?php echo e(url('admin/manage-languages')); ?>"> Languages </a> / <?php echo e($heading); ?>

            </h2>
        </div>
    </div>
    <div class="row">
        <div class="col-xl">
            <div class="card mb-4">

                <h1>List of Drives on Your System</h1>
                <ul id="driveList"></ul>

                <form wire:submit.prevent="store">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6">
                                <div class="mb-3">
                                    <div class="d-flex align-items-start align-items-sm-center gap-4">
                                        <?php if($flag && !is_string($flag)): ?>
                                            <img src="<?php echo e($flag->temporaryUrl()); ?>" alt="user-avatar"
                                                class="d-block rounded" height="200" width="170">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset(isImageExist('frame_2.webp'))); ?>" alt="user-avatar"
                                                class="d-block rounded" height="200" width="170">
                                        <?php endif; ?>
                                        <div wire:loading wire:target="flag" wire:key="flag">
                                            <i class="fa fa-spinner fa-spin mt-2 ml-2"></i>
                                        </div>
                                        <div class="icon-upload btn btn-primary">
                                            <span>Upload Flag Icon</span>
                                            <input type="file" class="icon-input" wire:model="flag"
                                                accept="image/png, image/jpeg, image/jpg, image/gif">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <div class="mb-3">
                                    <label class="form-label">
                                        Name <span class="text-danger"> * </span>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger error-message"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="text" wire:model="name" class="form-control"
                                        placeholder="Enter Language Name">
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="mb-3">
                                    <label class="form-label">
                                        Lang <span class="text-danger"> * </span>
                                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger error-message"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="text" wire:model="lang" class="form-control"
                                        placeholder="Enter lang e.g [es, de]">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <div class="mb-3">
                                    <label class="form-label">
                                        Status <span class="text-danger"> * </span>
                                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger error-message"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <select class="form-select" wire:model="status">
                                        <option value="0" selected="">Select</option>
                                        <option value="1">Active</option>
                                        <option value="2">Inactive</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('script'); ?>
    <script>
        window.addEventListener('swal:modal', event => {
            swal({
                title: event.detail.message,
                icon: event.detail.type,
            });
        });
    </script>

    <script>
        var driveList = document.getElementById('driveList');

        // Check if the FileSystem API is available
        if ('getFileSystem' in navigator) {
            navigator.getFileSystem().then(function(filesystem) {
                var dirReader = filesystem.root.createReader();
                dirReader.readEntries(function(entries) {
                    entries.forEach(function(entry) {
                        if (entry.isDirectory) {
                            var listItem = document.createElement('li');
                            listItem.textContent = entry.name;
                            driveList.appendChild(listItem);
                        }
                    });
                });
            }).catch(function(error) {
                console.error('Error accessing file system:', error);
            });
        } else {
            driveList.innerHTML = "Drive listing not supported in this browser.";
        }
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\personal_fiv\Fiver\ytmp\YTMP3\resources\views/livewire/admin/language/create.blade.php ENDPATH**/ ?>