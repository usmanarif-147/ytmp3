<div class="section-posts" data-v-8fbc4ecc>
    <div class="section-posts-wave" data-v-8fbc4ecc></div>
    <div class="section-posts-content" data-v-8fbc4ecc>
        <div class="container" data-v-8fbc4ecc>
            <div class="section-title" data-v-8fbc4ecc>Useful Posts</div>
            <div class="row">
                <div class="col-12 col-md-4">
                    <div class="box bg-white p-4 rounded">
                        <p>
                            Lorem, ipsum dolor sit amet consectetur adipisicing
                            elit. Obcaecati, incidunt.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\personal_fiv\Fiver\ytmp\YTMP3\resources\views/livewire/home/partials/post-section.blade.php ENDPATH**/ ?>