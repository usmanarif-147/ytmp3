<div>
    <p> This is dashboard </p>
</div>
<?php /**PATH D:\personal_fiv\Fiver\ytmp\YTMP3\resources\views/livewire/admin/dashboard.blade.php ENDPATH**/ ?>