<div class="section-faq" data-v-8fbc4ecc>
    <div class="row" data-v-8fbc4ecc>
        <div class="col-8 offset-2">
            <h4 class="section-title" data-v-8fbc4ecc>FAQ of YTMP3.ch</h4>
            <div class="accordion" id="accordionExample">
                <?php $__currentLoopData = $page_faqs['page_faqs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                            <button style="height: 50px" class="accordion-button" type="button"
                                data-bs-toggle="collapse" data-bs-target="#collapseOne_<?php echo e($key); ?>"
                                aria-expanded="true" aria-controls="collapseOne">
                                <?php echo e($loop->index + 1); ?>. <?php echo e($faq['question']); ?>

                            </button>
                        </h2>
                        <div id="collapseOne_<?php echo e($key); ?>" class="accordion-collapse collapse show"
                            aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <?php echo e($faq['answer']); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\personal_fiv\Fiver\ytmp\YTMP3\resources\views/livewire/home/partials/faq-section.blade.php ENDPATH**/ ?>