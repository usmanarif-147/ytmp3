<div class="section-features" data-v-8fbc4ecc>
    <div class="container" data-v-8fbc4ecc>
        <h3 class="section-title" data-v-8fbc4ecc>
            <?php echo e($page_content['feature_title']); ?>

        </h3>
        <div class="text-center">
            <img src="<?php echo e(asset(isImageExist($page_content['feature_image']))); ?>" style="height: 100px; width: 200px;"
                class="img-fluid" alt="">
        </div>
        <div class="section-features-desc" data-v-8fbc4ecc>
            <?php echo $page_content['feature_description']; ?>

        </div>
    </div>
</div>
<?php /**PATH D:\personal_fiv\Fiver\ytmp\YTMP3\resources\views/livewire/home/partials/feature-section.blade.php ENDPATH**/ ?>