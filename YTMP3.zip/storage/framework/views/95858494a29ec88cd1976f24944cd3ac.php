<div>
    
    <?php echo $__env->make('livewire.home.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    <div data-warden-g-parm="eyJ1cmxfdHlwZSI6InNlcnZpY2UifQ==" class="main-section section" style="min-height: 800px"
        data-v-8fbc4ecc>

        
        <?php echo $__env->make('livewire.home.partials.download-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        
        <?php echo $__env->make('livewire.home.partials.help-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        
        <?php echo $__env->make('livewire.home.partials.feature-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        
        <?php if(count($page_faqs['page_faqs'])): ?>
            <?php echo $__env->make('livewire.home.partials.faq-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        

        
        
        
    </div>

    
    
    

    
    <?php echo $__env->make('livewire.home.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</div>
<?php /**PATH D:\personal_fiv\Fiver\ytmp\YTMP3\resources\views/livewire/home/home.blade.php ENDPATH**/ ?>