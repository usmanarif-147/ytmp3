<div id="footer" class="section-footer" data-v-32865e22>
    <div class="container" data-v-32865e22>
        <div class="foot-links" data-v-32865e22>
            <div class="link-clomuns" data-v-32865e22>
                <a href="#" class="link-clomuns-cell" data-v-32865e22>
                    Terms of Use </a><a href="/cookies-policy" class="link-clomuns-cell" data-v-32865e22>
                    Cookies Policy </a><a href="/legal-disclaimer" class="link-clomuns-cell" data-v-32865e22>
                    Legal Disclaimer
                </a>
            </div>
            <div class="link-clomuns" data-v-32865e22>
                <a href="#" class="link-clomuns-cell" data-v-32865e22>
                    DMCA </a><a href="/privacy-policy" class="link-clomuns-cell" data-v-32865e22>
                    Privacy Policy </a><a href="/sitemap.xml" class="link-clomuns-cell" data-v-32865e22>
                    Sitemap
                </a>
            </div>
            <div class="link-clomuns" data-v-32865e22>
                <a href="#" class="link-clomuns-cell" data-v-32865e22>
                    Contact Us </a><a href="/" class="link-clomuns-cell" data-v-32865e22>
                    Home
                </a>
            </div>
            <div class="link-clomuns" data-v-32865e22>
                <a href="#" target="_blank" class="link-clomuns-cell" data-v-32865e22>
                    YouTubeToMP3 </a><a href="https://listentoyoutube.ch/youtube-audio-downloader" target="_blank"
                    class="link-clomuns-cell" data-v-32865e22>
                    YouTube Audio Downloader </a><a href target="_blank" class="link-clomuns-cell" data-v-32865e22>
                </a>
            </div>

            {{-- <div class="link-clomuns" data-v-32865e22>
                <a href="https://youtubetomp3.media/" target="_blank" class="link-clomuns-cell" data-v-32865e22>
                    YouTubeToMP3 </a><a href="https://listentoyoutube.ch/youtube-audio-downloader" target="_blank"
                    class="link-clomuns-cell" data-v-32865e22>
                    YouTube Audio Downloader </a><a href target="_blank" class="link-clomuns-cell" data-v-32865e22>
                </a>
            </div> --}}
        </div>
    </div>
    <div class="page-copyright container" data-v-32865e22>
        <span data-v-32865e22>Copyright © 2023 ytmp3.ch. All rights reserved.</span>
    </div>
</div>
